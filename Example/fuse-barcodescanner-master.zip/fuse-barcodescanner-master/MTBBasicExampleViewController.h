//
//  MTBViewController.h
//  MTBBarcodeScannerExample
//
//  Created by Mike Buss on 2/8/14.
//
//

#import <UIKit/UIKit.h>

@interface MTBBasicExampleViewController : UIViewController

@end