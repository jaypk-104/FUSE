module.exports = {
	clientID: "your client id",
	clientSecret: "your client secret"
};
