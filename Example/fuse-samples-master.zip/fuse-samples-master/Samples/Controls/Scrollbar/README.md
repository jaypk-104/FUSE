# A scroll bar while scrolling

This example shows how to create a scrolling indicator for a `ScrollView` that is only visible while the user is actively scrolling. It uses `ScrollingAnimation` and `WhileInteracting`.
