# Filter on an Observable Condition

This example shows how one can filter a list based on a condition which itself is an Observable event.
