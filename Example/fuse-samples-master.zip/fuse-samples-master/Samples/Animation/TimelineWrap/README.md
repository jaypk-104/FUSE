# A dynamic looping animation using Timeline

This example uses multiple `Timelines` to create a dynamic animation. Each `Dot` it the display has two `Timeline` objects that define it's behaviour. By using the `Dot.TimeOffset` and `Timeline.InitialProgress` properties we stagger the playback position of the dots.
