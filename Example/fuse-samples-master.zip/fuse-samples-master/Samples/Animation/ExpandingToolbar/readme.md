# Toolbar Animation

A Fuse implementation of [this awesome design](https://dribbble.com/shots/2695693-Toolbar-Animation-in-Framer-js) by [Yukyung Kim](https://dribbble.com/yukyungkim).
Icons are from Google's [Material Icons Pack](https://design.google.com/icons/).

![Animated GIF](https://d3vv6lp55qjaqc.cloudfront.net/items/3T1g2d1Q2d2z0V2q3W2L/expanding-toolbar.gif)
