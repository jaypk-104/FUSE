## AttractorMotion

This demonstrates several aspects of the `Fuse.Motion` package as exposed through the `Attractor`. Each cell in the grid is a distinct test with instructions at the top.
