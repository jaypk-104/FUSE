# ForeignAccelerometer

This example illustrates how you can wrap a piece of native OS functionality for multiple platforms using Fuse's [foreign code](https://www.fusetools.com/docs/native-interop/foreign-code) feature.

The actual accelerometer implementation resides in the [`ForeignAccelerometer/`](https://github.com/fusetools/fuse-samples/tree/master/Samples/ForeignAccelerometer/ForeignAccelerometer) subdirectory.