# Native dialogs

Sample code for an implementation of native dialogs with JS API. Only Android implemented, but stub class for iOS is provided.

Check the `MainView.ux` in the ExampleProject to see how to use it.