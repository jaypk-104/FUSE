# GPS Basics Fuse Example

Example project to accompany the "[GPS Basics](https://youtu.be/OapOMsUk3rE)" Fuse tutorial video. This is a really basic app showing 3 different ways to use FuseJS' GeoLocation API to get the location of our device. All relevant code is in the `MainView.ux`file.
