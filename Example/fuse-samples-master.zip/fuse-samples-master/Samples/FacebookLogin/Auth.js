module.exports = {
	client_id : "put your client id here"
};
