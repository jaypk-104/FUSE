The sounds used in this example are taken from [Analog Kit Lite by fugwhump](http://ccmixter.org/files/fugwhump/17527)
and are licensed under [Creative Commons Attribution (3.0)](http://creativecommons.org/licenses/by/3.0/) license.
