package com.fuse.BackgroundDownload;

public class CompleteDownload
{
    public final int ID;
    public final String Path;

    public CompleteDownload(int id, String path)
    {
        ID = id;
        Path = path;
    }
}
