# fuse.QrScanner

This library currently only supports android. please see MainView.us file for example how to use.