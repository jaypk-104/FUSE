#ifndef __BOOTSTRAP_ANDROID_HEADER__
#define __BOOTSTRAP_ANDROID_HEADER__
void BootstrapperImpl();
#endif
