package com.foreign;
public interface UnoWrapped { long _GetUnoPtr(); }
