// @(MSG_ORIGIN)
// @(MSG_EDIT_WARNING)

//#pragma message ( "Deprecated: Please include <uno.h> instead." )
#include "../uno.h"
