#pragma once

#ifndef NS_DESIGNATED_INITIALIZER
#   define NS_DESIGNATED_INITIALIZER
#endif

#include <uno.h>
#include <@{global::ObjC.ID:Include}>
#include <@{global::ObjC.Object:Include}>
#include "uObjC.Box.h"
#include "uObjC.Function.h"
#include "uObjC.String.h"
#include "uObjC.UnoArray.h"
#include "uObjC.UnoObject.h"
