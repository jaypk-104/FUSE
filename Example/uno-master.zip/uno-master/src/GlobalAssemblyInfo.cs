using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Fast, native C# dialect and cross-compiler.")]
[assembly: AssemblyDescription("Fast, native C# dialect and cross-compiler.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Fuse Open")]
[assembly: AssemblyProduct("uno")]
[assembly: AssemblyCopyright("Copyright © 2018-present Fuse Open")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("d159dc86-f510-4fcf-9573-e339bdd6d166")]

// Version information.
[assembly: AssemblyVersion("2.0.0.0")]
[assembly: AssemblyFileVersion("2.0.0.0")]
[assembly: AssemblyInformationalVersion("2.0.0-beta.4")]
