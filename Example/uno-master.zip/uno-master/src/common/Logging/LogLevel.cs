﻿namespace Uno.Logging
{
    public enum LogLevel
    {
        Compact,
        Verbose,
        VeryVerbose,
        UltraVerbose
    }
}
