using System;

namespace Uno.Logging
{
    public class MaxErrorException : Exception
    {
    }
}