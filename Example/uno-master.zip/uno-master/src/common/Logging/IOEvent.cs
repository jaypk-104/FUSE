namespace Uno.Logging
{
    public enum IOEvent
    {
        Read,
        Write,
        MkDir,
        Rm,
        RmDir,
        Include,
        Ignore,
        Build
    }
}