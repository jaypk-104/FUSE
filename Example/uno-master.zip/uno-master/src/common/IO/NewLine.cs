namespace Uno.IO
{
    public enum NewLine
    {
        Lf, // Unix
        CrLf, // Windows
    }
}