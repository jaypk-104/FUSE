namespace Uno
{
    public class SourceObject
    {
        public Source Source;

        public SourceObject(Source src)
        {
            Source = src;
        }
    }
}