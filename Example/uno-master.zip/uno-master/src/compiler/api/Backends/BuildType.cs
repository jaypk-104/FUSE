﻿namespace Uno.Compiler.API.Backends
{
    public enum BuildType
    {
        Executable,
        Library,
    }
}