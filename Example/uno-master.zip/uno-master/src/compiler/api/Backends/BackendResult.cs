﻿namespace Uno.Compiler.API.Backends
{
    public class BackendResult
    {
    }
}