namespace Uno.Compiler.API.Domain
{
    public enum CastModifier : byte
    {
        Implicit = 1,
        Explicit
    }
}