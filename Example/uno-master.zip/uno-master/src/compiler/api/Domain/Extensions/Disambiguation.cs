namespace Uno.Compiler.API.Domain.Extensions
{
    public enum Disambiguation
    {
        None,
        Default,
        Condition,
        Override,
    }
}