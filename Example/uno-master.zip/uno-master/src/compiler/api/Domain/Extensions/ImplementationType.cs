namespace Uno.Compiler.API.Domain.Extensions
{
    public enum ImplementationType
    {
        None,
        Body,
        EmptyBody,
        Expression,
    }
}