namespace Uno.Compiler.API.Domain.AST
{
    public enum AstNodeType : byte
    {
        Node,
        Drawable
    }
}