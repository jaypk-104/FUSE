namespace Uno.Compiler.API.Domain.AST
{
    public enum AstClassType : byte
    {
        Class,
        Struct,
        Interface
    }
}