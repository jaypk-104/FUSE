namespace Uno.Compiler.API.Domain.AST
{
    public enum AstConstraintType
    {
        None,
        Class,
        Struct
    }
}