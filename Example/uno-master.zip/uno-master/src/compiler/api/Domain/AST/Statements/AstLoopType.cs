namespace Uno.Compiler.API.Domain.AST.Statements
{
    public enum AstLoopType
    {
        While = AstStatementType.While,
        DoWhile = AstStatementType.DoWhile
    }
}