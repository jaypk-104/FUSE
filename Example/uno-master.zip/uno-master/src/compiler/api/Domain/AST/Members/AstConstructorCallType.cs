namespace Uno.Compiler.API.Domain.AST.Members
{
    public enum AstConstructorCallType : byte
    {
        None,
        Base,
        This,
    }
}