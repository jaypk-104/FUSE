﻿namespace Uno.Compiler.API.Domain.AST.Members
{
    public abstract class AstBlockMember
    {
        public abstract AstMemberType MemberType { get; }
    }
}
