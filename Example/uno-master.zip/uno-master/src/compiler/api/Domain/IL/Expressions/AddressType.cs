namespace Uno.Compiler.API.Domain.IL.Expressions
{
    public enum AddressType
    {
        Const = 1,
        Ref,
        Out,
    }
}