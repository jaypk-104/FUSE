﻿namespace Uno.Compiler.API.Domain.IL.Expressions
{
    public class Resource
    {
        public SourcePackage Package;
        public string Identifier;
        public DataType DataType;
    }
}
