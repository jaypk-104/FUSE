namespace Uno.Compiler.API.Domain.IL.Expressions
{
    public enum EqualityType
    {
        Equal,
        NotEqual,
    }
}