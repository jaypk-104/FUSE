namespace Uno.Compiler.API.Domain.IL
{
    public enum EntityType
    {
        Other,
        Namescope,
        Member,
        Variable,
    }
}