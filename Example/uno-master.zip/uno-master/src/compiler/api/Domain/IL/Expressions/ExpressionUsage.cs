namespace Uno.Compiler.API.Domain.IL.Expressions
{
    public enum ExpressionUsage
    {
        Statement,
        Argument,
        VarArg,
        Operand,
        Object,
    }
}