namespace Uno.Compiler.API.Domain.IL
{
    public enum NamescopeType
    {
        Other,
        Namespace,
        DataType,
        BlockBase
    }
}