namespace Uno.Compiler.API.Domain.IL
{
    public interface ITypeReference
    {
        DataType ReferencedType { get; }
    }
}