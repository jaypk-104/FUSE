namespace Uno.Compiler.API.Domain.IL.Expressions
{
    public enum CastType
    {
        Default,
        Up,
        Down,
        Box,
        Unbox
    }
}