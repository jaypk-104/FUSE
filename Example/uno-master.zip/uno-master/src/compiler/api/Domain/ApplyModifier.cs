namespace Uno.Compiler.API.Domain
{
    public enum ApplyModifier : byte
    {
        Undefined,
        Sealed,
        Virtual,
    }
}