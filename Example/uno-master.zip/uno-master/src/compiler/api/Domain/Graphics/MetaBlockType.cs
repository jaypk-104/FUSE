namespace Uno.Compiler.API.Domain.Graphics
{
    public enum MetaBlockType
    {
        Scope,
        Drawable,
    }
}