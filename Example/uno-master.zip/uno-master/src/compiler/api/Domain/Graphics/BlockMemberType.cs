namespace Uno.Compiler.API.Domain.Graphics
{
    public enum BlockMemberType
    {
        Node,
        Apply,
        MetaProperty,
    }
}