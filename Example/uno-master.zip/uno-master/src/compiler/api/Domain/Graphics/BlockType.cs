namespace Uno.Compiler.API.Domain.Graphics
{
    public enum BlockType
    {
        Block,
        MetaBlock,
        DrawBlock,
    }
}