namespace Uno.Compiler.API.Domain.Graphics
{
    public enum ShaderType
    {
        Vertex,
        Pixel
    }
}