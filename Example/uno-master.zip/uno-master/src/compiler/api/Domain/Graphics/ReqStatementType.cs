namespace Uno.Compiler.API.Domain.Graphics
{
    public enum ReqStatementType
    {
        Object,
        Property,
        File,
    }
}