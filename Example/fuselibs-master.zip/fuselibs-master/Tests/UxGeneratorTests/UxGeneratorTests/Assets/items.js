items = Observable([]);

function addItem() {
    items.add({ text: "This is an item" });
}