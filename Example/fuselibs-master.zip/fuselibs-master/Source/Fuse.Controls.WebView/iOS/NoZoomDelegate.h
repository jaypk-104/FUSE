#import <UIKit/UIKit.h>
@interface NoZoomDelegate : NSObject<UIScrollViewDelegate>
@end
