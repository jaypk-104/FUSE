
// This file is here to test that OptionalExplicit.ux takes this file as
// precedence over a dependency with the same name.
exports.haha = 1337;