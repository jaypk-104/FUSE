### Update JavaScriptCore headers

Currently it can only be done on macOS by replacing `Headers/JavaScriptCore` with `/System/Library/Frameworks/JavaScriptCore.framework/Headers`.