There are FuseJS tests.

# Adding new tests

All tests are olaced in `tests` directory. If you need to add new tests, you can do this in two ways:
* extend existing test file.
* simply add new js file in `test` directory.

# Run tests from browser

The simplest way to run tests is open `index.html` in your browser. 

# Run tests from NodeJS

Assumption: NodeJS is installed.
To run tests from NodeJS you just need to type `node testRunner.js`.

# Run tests from TC

Assumption: NodeJS is installed.
To run tests from TC you just need to type `node testRunner.js --teamcity`.