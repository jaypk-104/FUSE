We are using this lib https://github.com/stefanpenner/es6-promise
To update:

`npm install es6-promise --save`

And then replace `./es6-promise.min.js` with the one from `./node_modules/es6-promise/dist/es6-promise.auto.min.js`

Then delete `node_modules` folder.