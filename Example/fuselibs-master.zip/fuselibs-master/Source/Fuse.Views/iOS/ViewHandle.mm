#import "ViewHandle.h"

@implementation ViewHandle
-(void) setDataJson:(NSString*)json {}
-(void) setDataString:(NSString*)value forKey:(NSString*)key {}
-(void) setCallback:(Callback)callback forKey:(NSString*)key {}
@end