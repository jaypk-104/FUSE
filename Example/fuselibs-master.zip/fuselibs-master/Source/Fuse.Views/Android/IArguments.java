package com.fuse.views;

import java.util.HashMap;

public interface IArguments {
	HashMap<String,String> getArgs();
	String getDataJson();
}