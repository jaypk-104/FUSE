package com.fuse.views;

public interface ICallback {
	void invoke(IArguments eventRecord);
}