package com.fuse.views.internal;

public interface IExportedViews {
	com.fuse.views.ViewHandle instantiate(String uxClassName);
}