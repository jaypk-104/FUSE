# Remarks

`Text` is the primary control for displaying read-only text in apps. 