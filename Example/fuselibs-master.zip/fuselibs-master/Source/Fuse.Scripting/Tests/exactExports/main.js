var a = require('./a');
test.assert(a.main() === exports, 'exact exports');