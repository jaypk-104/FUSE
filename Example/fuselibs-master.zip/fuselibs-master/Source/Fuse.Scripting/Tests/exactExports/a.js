exports.main = function () {
    return require('main');
};
