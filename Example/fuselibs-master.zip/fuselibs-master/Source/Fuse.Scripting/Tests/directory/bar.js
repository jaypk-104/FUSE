module.exports = require('./bar/baz')
