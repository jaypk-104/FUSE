module.exports = 'baz'
