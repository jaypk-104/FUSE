require('main').monkey = 10;
