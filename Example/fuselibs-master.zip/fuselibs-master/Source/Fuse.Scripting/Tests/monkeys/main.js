var a = require('./a');
test.assert(exports.monkey == 10, 'monkeys permitted');
