exports.foo = function () {
    return require('absolute/b');
};
