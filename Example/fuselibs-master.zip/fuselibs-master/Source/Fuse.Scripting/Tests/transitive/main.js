test.assert(require('transitive/a').foo() == 1, 'transitive');
