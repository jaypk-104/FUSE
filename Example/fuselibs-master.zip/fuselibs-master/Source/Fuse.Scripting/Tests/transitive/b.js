exports.foo = require('transitive/c').foo;
