exports.foo = require('transitive/b').foo;
