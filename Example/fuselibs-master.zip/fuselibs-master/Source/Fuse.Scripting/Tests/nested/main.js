test.assert(require('nested/a/b/c/d').foo() == 1, 'nested module identifier');
