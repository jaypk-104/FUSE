//console.log('eval a');
require('./a-web');
module.exports = mycustomobject;
