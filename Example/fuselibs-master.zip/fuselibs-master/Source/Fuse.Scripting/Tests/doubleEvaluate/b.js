//console.log('eval b');
require('./a-web.js');
require('./b-web.js');
module.exports = mycustomobject.innerobject;

