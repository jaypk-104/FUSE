//console.log('eval b-web');
evalBCount++;
mycustomobject.innerobject = { name: 'b-web' };
