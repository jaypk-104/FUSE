//console.log('eval a-web');
evalACount++;
mycustomobject = { name: "a-web" };
