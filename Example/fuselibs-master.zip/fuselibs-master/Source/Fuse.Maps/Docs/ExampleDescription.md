This example displays a map with an average zoom level focused on Fuse's home in Oslo, Norway
