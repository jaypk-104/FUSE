package com.fuse.android.views;

public interface ScrollEventHandler {
	public void onScrollChanged(int x, int y, int oldX, int oldY);
}