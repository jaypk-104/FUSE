While `Radius` is an animatable property, changing it is potentially an expensive operation.
Make sure to test it on slower devices so that it doesn't cause a massive decrease in performance.