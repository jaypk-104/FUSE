The following example displays a blurred @Rectangle.

	<Rectangle Margin="40" Color="#9b59b6">
	    <Blur Radius="15" />
	</Rectangle>