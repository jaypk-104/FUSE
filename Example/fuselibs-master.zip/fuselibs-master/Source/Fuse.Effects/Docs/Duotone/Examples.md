The following example applies a duotone effect with some nice colors to an image.

	<Image File="testImage.png">
		<DuoTone Light="#75DD73" Shadow="#242365" Amount="0.9"/>
	</Image>
