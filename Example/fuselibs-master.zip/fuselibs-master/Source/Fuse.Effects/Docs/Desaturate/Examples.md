The following example displays a completely desaturated @Rectangle.

	<Rectangle Color="#f00">
	    <Desaturate Amount="1" />
	</Rectangle>