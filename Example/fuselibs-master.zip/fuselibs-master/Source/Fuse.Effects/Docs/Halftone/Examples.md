The below example shows a halftone effect applied to an image.

	<Image File="cat.jpg" StretchMode="UniformToFill">
	    <Halftone DotTint="0" PaperTint="0.95" Intensity="0.9" Smoothness="2" Spacing="15" />
	</Image>