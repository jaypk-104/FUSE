#pragma once

#include <harfbuzz/hb.h>

void hb_ft_font_cached_set_funcs(hb_font_t* font);
