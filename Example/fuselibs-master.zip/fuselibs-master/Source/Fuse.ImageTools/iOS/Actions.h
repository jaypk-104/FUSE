typedef void (^Action)(void);
typedef void (^StringAction)(NSString*);
typedef void (^DictionaryAction)(NSDictionary*);