export default class {
	constructor() {
		this.array = [];
	}

	push() {
		this.array.push([0,1,2]);
	}
}