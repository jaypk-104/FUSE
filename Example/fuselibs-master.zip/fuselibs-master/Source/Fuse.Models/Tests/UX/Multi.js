export default class Multi {
	constructor() {
		this.Value = undefined;
	}

	get value() {
		return this.Value;
	}
}