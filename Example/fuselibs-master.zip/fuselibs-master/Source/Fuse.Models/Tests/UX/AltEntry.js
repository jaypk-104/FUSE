import * as common from "UX/AltEntryCommon"

export default class ModelAltEntry {
	constructor() {
		this.item = common.item
	}
}