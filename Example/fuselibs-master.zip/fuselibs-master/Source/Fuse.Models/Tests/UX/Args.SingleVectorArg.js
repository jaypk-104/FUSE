export default class {
	constructor(input) {
		this.result = input.external_object;
	}
}